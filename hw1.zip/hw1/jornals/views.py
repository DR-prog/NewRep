from django.shortcuts import render
from django.shortcuts import render
from django.views.generic import ListView, DetailView,CreateView,UpdateView,DeleteView
from .models import  Jornal

class JornalListView(ListView):
    model = Jornal
    template_name = "jornals.html"
    context_object_name = "jornals"
class JornalDetailView(DetailView):
    model = Jornal
    template_name = "jornals_detail.html"
    context_object_name = "jornal"
class Jornal_ReversedListView(ListView):
    model = Jornal
    template_name = "jornals_reversed.html"
    context_object_name = "jornals_reversed"
# Create your views here.

# Create your views here.
