
from django.contrib import admin
from .models import Jornal
admin.site.register(Jornal)

