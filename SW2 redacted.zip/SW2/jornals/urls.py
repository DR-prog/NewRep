from django.urls import path 
from .views import JornalListView,JornalDetailView,Jornal_ReversedListView
urlpatterns = [
    path("jornal/<int:pk>/", JornalDetailView.as_view(), name="jornals_detail"),
    path("jornals/", JornalListView.as_view(), name="jornals"),
    path("jornals_reversed/", Jornal_ReversedListView.as_view(), name="jornals_reversed"),
]