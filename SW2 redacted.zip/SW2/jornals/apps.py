from django.apps import AppConfig


class JornalsConfig(AppConfig):
    name = 'jornals'
