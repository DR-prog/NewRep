from django.contrib import admin
from .models import Jornal
admin.site.register(Jornal)
# Register your models here.
