from django.apps import AppConfig


class HpageConfig(AppConfig):
    name = 'hpage'
