from .models import RegularUser
from django.contrib import admin
from .forms import RegularUserChangeForm, RegularUserCreationForm
from django.contrib.auth.admin import UserAdmin 
# Register your models here.
class RegularUserAdmin(UserAdmin):
    add_form = RegularUserCreationForm
    form = RegularUserChangeForm
    model = RegularUser
    list_display = ["email", "age", "username", "is_staff","phone_number","sex","postal_code"]
admin.site.register(RegularUser, RegularUserAdmin)
# Register your models here.
