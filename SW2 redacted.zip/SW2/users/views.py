from django.shortcuts import render
from django.urls import reverse_lazy
from .forms import RegularUserCreationForm
from django.views.generic import ListView, DetailView,CreateView,UpdateView,DeleteView
from django.urls import reverse_lazy
from .forms import RegularUserCreationForm
class SignUpView(CreateView):
    form_class = RegularUserCreationForm
    success_url = reverse_lazy("login")
    template_name = "signup.html"
# Create your views here.
