from django.shortcuts import render
from django.views.generic import ListView, DetailView,CreateView,UpdateView,DeleteView
from .models import Book

# Create your views here.
class BookListView(ListView):
    model = Book
    template_name = "books.html"
    context_object_name = "books"
class BookDetailView(DetailView):
    model = Book
    template_name = "books_detail.html"
    context_object_name = "book"
class Book_ReversedListView(ListView):
    model = Book
    template_name = "books_reversed.html"
    context_object_name = "books_reversed"