from .models import RegularUser
from django.contrib.auth.forms import UserCreationForm, UserChangeForm
class RegularUserCreationForm(UserCreationForm):
    class Meta(UserCreationForm.Meta):
        model = RegularUser
        fields = UserCreationForm.Meta.fields  
class RegularUserChangeForm(UserChangeForm):
    class Meta(UserChangeForm.Meta):
        model = RegularUser
        fields = UserChangeForm.Meta.fields 
