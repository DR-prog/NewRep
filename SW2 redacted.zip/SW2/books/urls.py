from django.urls import path 
from .views import BookListView, BookDetailView,Book_ReversedListView
urlpatterns = [
    path("book/<int:pk>/", BookDetailView.as_view(), name="books_detail"),
    path("books/", BookListView.as_view(), name="books"),
    path("books/books_reversed/", Book_ReversedListView.as_view(), name="books_reversed"),
]
